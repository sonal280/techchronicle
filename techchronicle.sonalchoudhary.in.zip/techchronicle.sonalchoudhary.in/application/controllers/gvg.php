<?php 
defined('BASEPATH') OR exit('No direct script access allowed');
class Category extends CI_controller
{
	
	public function __construct(argument)
	{
		parett::__construct();
		$this->load->Model('news_portal_model');
	}

	public function ($value='')
	{
		# code...
	}

}

 ?>