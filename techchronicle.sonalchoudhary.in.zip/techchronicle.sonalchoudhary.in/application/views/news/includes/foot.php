<!-- all js here -->
	<script src="<?=base_url('assets/js/jquery.min.js')?>"></script>
    <!-- jquery latest version -->
    <script src="<?=base_url('assets/js/jquery.min.js')?>"></script>
	 <!-- jquery-ui js -->
    <script src="<?=base_url('assets/js/jquery-ui.min.js')?>"></script>
    <!-- bootstrap js -->
    <script src="<?=base_url('assets/js/bootstrap.min.js')?>"></script>
    <!-- meanmenu js -->
    <script src="<?=base_url('assets/js/jquery.meanmenu.js')?>"></script>
    <!-- wow js -->
    <script src="<?=base_url('assets/js/wow.min.js')?>"></script>
	<!-- owl.carousel js -->
    <script src="<?=base_url('assets/js/owl.carousel.min.js')?>"></script>
    <!-- magnific-popup js -->
    <script src="<?=base_url('assets/js/jquery.magnific-popup.js')?>"></script>
	
    <!-- jquery.counterup js -->
    <script src="<?=base_url('assets/js/jquery.counterup.min.js')?>"></script>
    <script src="<?=base_url('assets/js/waypoints.min.js')?>"></script>
    <!-- jquery light box -->
    <script src="<?=base_url('assets/js/lightbox.min.js')?>"></script>
    <!-- Nivo slider js -->
    <script src="<?=base_url('assets/inc/custom-slider/js/jquery.nivo.slider.js" type="text/javascript')?>"></script>
    <script src="<?=base_url('assets/inc/custom-slider/home.js" type="text/javascript')?>"></script>
    <!-- main js -->
    <script src="<?=base_url('assets/js/main.js')?>"></script>