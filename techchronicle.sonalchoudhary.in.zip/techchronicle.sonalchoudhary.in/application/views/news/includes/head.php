 <meta charset="utf-8">
    <meta http-equiv="x-ua-compatible" content="ie=edge">
    <title>Tech Chronicle</title>
    <meta name="description" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="apple-touch-icon" href="apple-touch-icon.html">
    <link rel="shortcut icon" type="image/x-icon" href="<?=base_url('assets/images/fav.png')?>">
    <!-- Place favicon.ico in the root directory -->
    <!-- all css here -->
    <!-- bootstrap v3.3.6 css -->
    <link rel="stylesheet" href="<?=base_url('assets/css/bootstrap.min.css')?>">
    <!-- font-awesome css -->
    <link rel="stylesheet" href="<?=base_url('assets/css/font-awesome.min.css')?>">
    <!-- animate css -->
    <link rel="stylesheet" href="<?=base_url('assets/css/animate.css')?>">
    <!-- hover-min css -->
    <link rel="stylesheet" href="<?=base_url('assets/css/hover-min.css')?>">
      <!-- magnific-popup css -->
    <link rel="stylesheet" href="<?=base_url('assets/css/magnific-popup.css')?>">
    <!-- meanmenu css -->
    <link rel="stylesheet" href="<?=base_url('assets/css/meanmenu.min.css')?>">
    <!-- owl.carousel css -->
    <link rel="stylesheet" href="<?=base_url('assets/css/owl.carousel.css')?>">
    <!-- lightbox css -->
    <link href="<?=base_url('assets/css/lightbox.min.css')?>" rel="stylesheet">
    <!-- nivo slider CSS -->
    <link rel="stylesheet" href="<?=base_url('assets/inc/custom-slider/css/nivo-slider.css')?>" type="text/css" />
    <link rel="stylesheet" href="<?=base_url('assets/inc/custom-slider/css/preview.css')?>" type="text/css" media="screen" />
    <!-- style css -->
    <link rel="stylesheet" href="<?=base_url('assets/css/style.css')?>">
    <!-- responsive css -->
    <link rel="stylesheet" href="<?=base_url('assets/css/responsive.css')?>">
    <!-- modernizr js -->
    <script src="<?=base_url('assets/js/modernizr-2.8.3.min.js')?>"></script>